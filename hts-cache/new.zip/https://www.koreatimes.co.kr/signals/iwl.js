<head><title>Document Moved</title></head>
<body><h1>Object Moved</h1>This document may be found <a HREF="https://www.koreatimes.co.kr/www2/common/404.html">here</a></body>